#Entradas
ano_atual = 2024
ano_nascimento = int(input( "QUAL O ANO QUE VOÇÊ NASCEU?"))

#Processamento
idade = ano_atual - ano_nascimento 

#Saída
print("Você tem "+str(idade)+" anos")